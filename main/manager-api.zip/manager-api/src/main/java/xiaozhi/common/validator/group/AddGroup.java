package xiaozhi.common.validator.group;

/**
 * 新增 Group
 */
public interface AddGroup {

}
