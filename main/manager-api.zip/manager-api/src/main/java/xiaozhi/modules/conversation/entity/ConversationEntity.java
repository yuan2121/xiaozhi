package xiaozhi.modules.conversation.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("ai_chat_history")
public class ConversationEntity {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    private Long userId;
    private String agentId;
    private String deviceId;
    private int messageCount;
    private Long creator;
    private String createDate;
    private Long updater;
    private String updateDate;
}