package xiaozhi.modules.conversation.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("ai_chat_message")
public class MessageEntity {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    private Long userId;
    private String chatId;
    private String role;
    private String content;
    private String promptTokens;
    private String totalTokens;
    private String completionTokens;
    private String promptMs;
    private String totalMs;
    private String completionMs;
    private Long creator;
    private String createDate;
    private Long updater;
    private String updateDate;
}