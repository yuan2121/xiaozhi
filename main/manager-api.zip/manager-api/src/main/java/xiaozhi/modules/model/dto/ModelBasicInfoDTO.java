package xiaozhi.modules.model.dto;

import lombok.Data;

@Data
public class ModelBasicInfoDTO {
    private String id;
    private String modelName;
}