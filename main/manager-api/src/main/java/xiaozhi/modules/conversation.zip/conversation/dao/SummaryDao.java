package xiaozhi.modules.conversation.dao;

import org.apache.ibatis.annotations.Mapper;
import xiaozhi.common.dao.BaseDao;
import xiaozhi.modules.conversation.entity.SummaryEntity;

@Mapper
public interface SummaryDao extends BaseDao<SummaryEntity> {

}
