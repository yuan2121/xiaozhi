package xiaozhi.modules.conversation.dto;

import lombok.Data;

@Data
public class SummaryDto {
    private String chatId;
    private String Summary;
}
